// DATE & TIME
// Website ke navigation me current date aur time show karne ke liye.

function updateDateTime(){

    const el = document.getElementById('datetime');

    if(!el) return;

    const d = new Date();

    el.textContent = d.toLocaleString('en-IN', {
        weekday:'short',
        day:'2-digit',
        month:'short',
        year:'numeric',
        hour:'2-digit',
        minute:'2-digit',
        second:'2-digit'
    });

}

setInterval(updateDateTime, 1000);

updateDateTime();


// MOBILE MENU
// Zoom-in, tablet aur mobile screens par hamburger menu open/close karne ke liye.
// Desktop/zoom-out par menu automatic normal single-line mode me aa jata hai.

const btn = document.querySelector('.menu-btn');

const nav = document.querySelector('.nav');

if(btn && nav){

    btn.addEventListener('click', () => {
        nav.classList.toggle('show');
    });

    document.querySelectorAll('.nav a').forEach((link) => {

        link.addEventListener('click', () => {
            nav.classList.remove('show');
        });

    });

    window.addEventListener('resize', () => {

        if(window.innerWidth > 1180){
            nav.classList.remove('show');
        }

    });

}


// ACTIVE NAV LINK
// Jo page open hai, uska menu item active orange color me show karne ke liye.

const page = location.pathname.split('/').pop() || 'index.html';

document.querySelectorAll('.nav a').forEach((a) => {

    if(a.getAttribute('href') === page){
        a.classList.add('active');
    }

});


// HERO SLIDESHOW
// Homepage ke hero section me images automatic change karne ke liye.

const slides = document.querySelectorAll('.hero-slideshow .slide');

let currentSlide = 0;

function showSlide(index){

    slides.forEach((slide) => {
        slide.classList.remove('active');
    });

    if(slides[index]){
        slides[index].classList.add('active');
    }

}

if(slides.length > 0){

    setInterval(() => {

        currentSlide++;

        if(currentSlide >= slides.length){
            currentSlide = 0;
        }

        showSlide(currentSlide);

    }, 3000);

}


// GALLERY
// Gallery page me sabhi categories ki images ek hi grid me show karne ke liye.

const galleryData = {

    center: [
        { image:"assets/images/center/finalcenter1.jpg", title:"Sandila Center" },
        { image:"assets/images/center/finalcenter2.jpg", title:"Sandila Center" },
        { image:"assets/images/center/finalcenter3.jpg", title:"Sandila Center Team" },
        { image:"assets/images/center/finalcenter4.jpg", title:"Sandila Center Lunch Time" },
        { image:"assets/images/center/finalcenter5.jpg", title:"Sandila Center" },
        { image:"assets/images/center/finalcenter6.jpg", title:"Sandila Center" }
    ],

    activities: [
        { image:"assets/images/activites/finalactivity1.jpg", title:"Provide Gifting for Spreading our Mission/Goal" },
        { image:"assets/images/activites/finalactivity2.jpg", title:"Awareness Program" },
        { image:"assets/images/activites/finalactivity3.jpg", title:"Awareness Program" },
        { image:"assets/images/activites/finalactivity4.jpg", title:"Awareness Program" },
        { image:"assets/images/activites/finalactivity5.jpg", title:"Awareness Program" },
        { image:"assets/images/activites/finalactivity6.jpg", title:"Awareness Program" }
    ],

    events: [
        { image:"assets/images/counselling/finalcounselling1.jpg", title:"Counselling Session" },
        { image:"assets/images/counselling/finalcounselling2.jpg", title:"Counselling Session" },
        { image:"assets/images/counselling/finalcounselling3.jpg", title:"Counselling Session" },
        { image:"assets/finalCouncelling1.jpg", title:"Counselling Session" },
        { image:"assets/finalCouncelling1.jpg", title:"Counselling Session" },
        { image:"assets/finalCouncelling1.jpg", title:"Counselling Session" }
    ],

    celebrations: [
        { image:"assets/images/events/finalevent1.jpg", title:"Republic Day Celebration" },
        { image:"assets/images/events/finalevent2.jpg", title:"Republic Day Celebration" },
        { image:"assets/images/events/finalevent3.jpg", title:"Independence Day Celebration" },
        { image:"assets/images/events/finalevent4.jpg", title:"Independence Day Celebration" },
        { image:"assets/images/events/finalevent5.jpg", title:"Independence Day Celebration" },
        { image:"assets/images/events/finalevent6.jpg", title:"2nd October Celebration" }
    ]

};

const tabButtons = document.querySelectorAll(".tabs button");

const galleryGrid = document.getElementById("galleryGrid");

if(galleryGrid){

    function createGalleryCard(item){

        return `
            <div class="photo photo-gallery">

                <img src="${item.image}" alt="${item.title}">

                <div class="gallery-title">
                    ${item.title}
                </div>

            </div>
        `;

    }

    function loadAllGallery(){

        const allGalleryImages = [
            ...galleryData.center,
            ...galleryData.activities,
            ...galleryData.events,
            ...galleryData.celebrations
        ];

        galleryGrid.innerHTML = allGalleryImages
            .map(createGalleryCard)
            .join("");

    }

    tabButtons.forEach((button) => {
        button.classList.remove("active");
    });

    loadAllGallery();

}


// TYPING EFFECT
// Homepage heading me English/Hindi typing animation chalane ke liye.

const typingText = document.getElementById("typing-text");

if(typingText){

    const words = [
    "STEP TOWARDS CHANGE",
    "बदलाव की नई राह"
    ];

    let wordIndex = 0;
    let letterIndex = 0;
    let deleting = false;

    function typingEffect(){

        const currentWord = words[wordIndex];

        typingText.textContent =
            currentWord.substring(0, letterIndex);

        if(!deleting){

            letterIndex++;

            if(letterIndex > currentWord.length){

                deleting = true;

                setTimeout(typingEffect, 1500);

                return;
            }

        }else{

            letterIndex--;

            if(letterIndex < 0){

                deleting = false;

                wordIndex++;

                if(wordIndex >= words.length){
                    wordIndex = 0;
                }

            }

        }

        setTimeout(
            typingEffect,
            deleting ? 60 : 120
        );

    }

    typingEffect();

}

// LOGO POPUP
// Logo par click karne par original size popup open/close karne ke liye.

function openLogoPopup(){

    document.getElementById("logoPopup").style.display = "flex";

}

function closeLogoPopup(){

    document.getElementById("logoPopup").style.display = "none";

}
